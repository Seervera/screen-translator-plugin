# Screen Translator - Godot Android Plugin

## المحتوى
- `plugin/src/main/kotlin/.../ScreenTranslatorPlugin.kt` — الكلاس الرئيسي: صلاحية Overlay، صلاحية والتقاط الشاشة (MediaProjection).
- `plugin/src/main/kotlin/.../ScreenCaptureService.kt` — Foreground Service مطلوبة إلزامياً من أندرويد 10+ لتشغيل MediaProjection.
- `plugin/src/main/AndroidManifest.xml` — الصلاحيات المطلوبة.
- `plugin/build.gradle` — إعدادات بناء الإضافة.
- `screentranslator.gdap` — ملف تعريف الإضافة الذي يقرأه Godot (يوضع مع ملف الـ AAR الناتج).
- `.github/workflows/build.yml` — بناء الـ AAR تلقائياً على سيرفرات GitHub (بدون Android Studio على جهازك).

## الدوال المتاحة من Godot (GDScript)

```gdscript
var plugin = null

func _ready():
    if Engine.has_singleton("ScreenTranslatorPlugin"):
        plugin = Engine.get_singleton("ScreenTranslatorPlugin")
        plugin.connect("overlay_permission_result", _on_overlay_result)
        plugin.connect("screen_capture_permission_result", _on_capture_permission_result)
        plugin.connect("screenshot_captured", _on_screenshot_captured)
        plugin.connect("screenshot_failed", _on_screenshot_failed)

func request_overlay():
    plugin.requestOverlayPermission()

func request_capture():
    plugin.requestScreenCapturePermission()

func take_screenshot(x, y, w, h):
    plugin.captureScreenRegion(x, y, w, h)

func _on_screenshot_captured(base64_png: String):
    var image = Image.new()
    var bytes = Marshalls.base64_to_raw(base64_png)
    image.load_png_from_buffer(bytes)
    # هنا تبعت الصورة لـ Azure OCR
```

## ملاحظات مهمة قبل الاستخدام
1. لسه محتاج نضيف الجزء اللي بيرسم الفقاعة العائمة فعلياً (Floating Bubble View) — ده هيتضاف في خطوة لاحقة، النسخة دي بتغطي الصلاحيات + الالتقاط فقط.
2. `getRealMetrics` مُستخدمة هنا للتبسيط، وهي deprecated في أندرويد الحديث؛ تشتغل لكن ممكن تستبدلها لاحقاً بـ WindowMetrics API.
3. مطلوب اختبار على جهاز حقيقي — صلاحيات MediaProjection غالباً بتتصرف بشكل غريب على المحاكي.
4. عدّل `namespace`/package name في build.gradle والملفات لو حابب اسم مختلف لمشروعك.

## خطوة البناء (لاحقاً)
هنستخدم GitHub Actions (`.github/workflows/build.yml`) للبناء بدون الحاجة لـ Android Studio على جهازك.
