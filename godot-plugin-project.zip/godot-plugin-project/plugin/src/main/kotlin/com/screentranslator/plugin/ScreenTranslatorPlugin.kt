package com.screentranslator.plugin

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import java.io.ByteArrayOutputStream

/**
 * إضافة Godot Android الأساسية للمشروع.
 * وظيفتها فقط: طلب الصلاحيات، إظهار overlay، والتقاط الشاشة.
 * الترجمة/OCR/TTS كلها بتتعمل في Godot عادي عن طريق HTTPRequest.
 */
class ScreenTranslatorPlugin(godot: Godot) : GodotPlugin(godot) {

    companion object {
        const val TAG = "ScreenTranslatorPlugin"
        const val REQUEST_CODE_OVERLAY = 5001
        const val REQUEST_CODE_SCREEN_CAPTURE = 5002
    }

    private var mediaProjectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    // نحتفظ بنتيجة صلاحية الشاشة لحد ما نستخدمها فعلياً بعد بدء الـ Foreground Service
    private var pendingResultCode: Int = 0
    private var pendingResultData: Intent? = null

    override fun getPluginName(): String = "ScreenTranslatorPlugin"

    // الإشارات (Signals) اللي هتوصل لـ Godot، تقدر تستقبلها زي أي Signal عادي
    override fun getPluginSignals(): MutableSet<SignalInfo> {
        return mutableSetOf(
            SignalInfo("overlay_permission_result", Boolean::class.javaObjectType),
            SignalInfo("screen_capture_permission_result", Boolean::class.javaObjectType),
            SignalInfo("screenshot_captured", String::class.java),
            SignalInfo("screenshot_failed", String::class.java)
        )
    }

    init {
        activity?.let {
            mediaProjectionManager =
                it.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        }
    }

    // ============ 1) صلاحية الظهور فوق التطبيقات (Overlay) ============

    @UsedByGodot
    fun isOverlayPermissionGranted(): Boolean {
        val ctx = activity ?: return false
        return Settings.canDrawOverlays(ctx)
    }

    @UsedByGodot
    fun requestOverlayPermission() {
        val ctx = activity ?: run {
            emitSignal("overlay_permission_result", false)
            return
        }
        if (Settings.canDrawOverlays(ctx)) {
            emitSignal("overlay_permission_result", true)
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + ctx.packageName)
        )
        activity?.startActivityForResult(intent, REQUEST_CODE_OVERLAY)
    }

    // ============ 2) صلاحية التقاط الشاشة (MediaProjection) ============

    @UsedByGodot
    fun requestScreenCapturePermission() {
        val mgr = mediaProjectionManager
        if (mgr == null) {
            emitSignal("screen_capture_permission_result", false)
            return
        }
        val intent = mgr.createScreenCaptureIntent()
        activity?.startActivityForResult(intent, REQUEST_CODE_SCREEN_CAPTURE)
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onMainActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_OVERLAY -> {
                val granted = activity?.let { Settings.canDrawOverlays(it) } ?: false
                emitSignal("overlay_permission_result", granted)
            }
            REQUEST_CODE_SCREEN_CAPTURE -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    pendingResultCode = resultCode
                    pendingResultData = data

                    // ملاحظة مهمة: من أندرويد 10+ لازم تبدأ Foreground Service
                    // قبل ما تستخدم getMediaProjection فعلياً، وإلا هيرمي SecurityException.
                    // ScreenCaptureService.kt المرفق بيعمل ده.
                    val ctx = activity
                    if (ctx != null) {
                        val serviceIntent = Intent(ctx, ScreenCaptureService::class.java)
                        ctx.startForegroundService(serviceIntent)
                    }

                    mediaProjection = mediaProjectionManager?.getMediaProjection(resultCode, data)
                    emitSignal("screen_capture_permission_result", true)
                } else {
                    emitSignal("screen_capture_permission_result", false)
                }
            }
        }
    }

    // ============ 3) التقاط منطقة من الشاشة ============

    /**
     * x, y, width, height: المنطقة المطلوب التقاطها بالبكسل (إحداثيات الشاشة الفعلية).
     * الناتج بيرجع كـ Base64 PNG عبر إشارة screenshot_captured، عشان تبعته زي ما هو
     * لـ Azure OCR API من Godot مباشرة بدون تخزين ملف.
     */
    @UsedByGodot
    fun captureScreenRegion(x: Int, y: Int, width: Int, height: Int) {
        val projection = mediaProjection
        val ctx = activity
        if (projection == null || ctx == null) {
            emitSignal("screenshot_failed", "no_permission")
            return
        }

        val metrics = DisplayMetrics()
        ctx.windowManager.defaultDisplay.getRealMetrics(metrics)
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = projection.createVirtualDisplay(
            "ScreenTranslatorCapture",
            metrics.widthPixels, metrics.heightPixels, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            try {
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * metrics.widthPixels

                var bitmap = Bitmap.createBitmap(
                    metrics.widthPixels + rowPadding / pixelStride,
                    metrics.heightPixels,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()

                // قص المنطقة المطلوبة فقط
                val safeX = x.coerceIn(0, bitmap.width - 1)
                val safeY = y.coerceIn(0, bitmap.height - 1)
                val safeWidth = width.coerceAtMost(bitmap.width - safeX)
                val safeHeight = height.coerceAtMost(bitmap.height - safeY)

                if (safeWidth > 0 && safeHeight > 0) {
                    bitmap = Bitmap.createBitmap(bitmap, safeX, safeY, safeWidth, safeHeight)
                }

                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                val base64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

                emitSignal("screenshot_captured", base64)
            } catch (e: Exception) {
                Log.e(TAG, "فشل التقاط الشاشة", e)
                emitSignal("screenshot_failed", e.message ?: "unknown_error")
            } finally {
                stopVirtualDisplay()
            }
        }, null)
    }

    private fun stopVirtualDisplay() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
    }

    @UsedByGodot
    fun stopScreenCapture() {
        stopVirtualDisplay()
        mediaProjection?.stop()
        mediaProjection = null
        activity?.let {
            it.stopService(Intent(it, ScreenCaptureService::class.java))
        }
    }
}
