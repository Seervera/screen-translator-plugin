package com.screentranslator.plugin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * خدمة بسيطة تعمل في المقدمة (Foreground Service).
 * أندرويد 10+ بيرفض تشغيل MediaProjection من غير Foreground Service شغالة،
 * وبيلزمك تظهر إشعار (Notification) دايم للمستخدم يوضحله إن التطبيق بيصور الشاشة
 * (ده مطلوب من نظام أندرويد نفسه لأسباب خصوصية، مش اختياري).
 */
class ScreenCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "screen_translator_capture_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ترجمة الشاشة - التقاط نشط",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "يظهر هذا الإشعار أثناء تفعيل التقاط الشاشة للترجمة"
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("ترجمة الشاشة")
            .setContentText("التقاط الشاشة نشط لأداء الترجمة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }
}
